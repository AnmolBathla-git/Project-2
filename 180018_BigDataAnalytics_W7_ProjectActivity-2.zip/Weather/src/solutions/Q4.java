package solutions;


import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Q4 {
	// Mapper Class
	public static class MapForMaximumAndMinimum extends Mapper<LongWritable, Text, Text, Text> {

		public void map(LongWritable name, Text text, Context context)
				throws IOException, InterruptedException {

			String word = text.toString();
			String date = word.substring(6, 14).replaceAll(" ", "");
			String t_high = word.substring(38, 45).replaceAll(" ", "");
			String t_low = word.substring(46, 53).replaceAll(" ", "");

			context.write(new Text(date), new Text(t_high + ":" + t_low));

		}
	}

	// Reducer Class
	public static class ReduceForMaximumAndMinimum extends Reducer<Text, Text, Text, Text> {

		TreeMap<Text, Text> tree = new TreeMap<Text, Text>();

		public void reduce(Text t_word, Iterable<Text> t_value, Context t_context)
				throws IOException, InterruptedException {

			for (Text value : t_value) {
				tree.put(new Text(t_word), new Text(value));
			}
		}

		public void cleanup(Context con) throws IOException,
				InterruptedException {
			con.write(new Text("Date"), new Text(
					"Max Temperature  and	Min Temperature"));

			for (Map.Entry<Text, Text> temp : tree.entrySet()) {
				String[] t = temp.getValue().toString().split(":");

				con.write(new Text(temp.getKey()), new Text(t[0] + "	"
						+ t[1]));
			}
		}
	}
	
	// Main Method for execution
		public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
			Configuration c= new Configuration();
			Job job = Job.getInstance(c, "Question 4:");
			job.setJarByClass(Q4.class);
			job.setMapperClass(MapForMaximumAndMinimum.class);
			job.setReducerClass(ReduceForMaximumAndMinimum.class);
			job.setOutputKeyClass(Text.class);
			job.setOutputValueClass(Text.class);
			FileInputFormat.addInputPath(job, new Path(args[0]));
			FileOutputFormat.setOutputPath(job, new Path(args[1]));
			System.exit(job.waitForCompletion(true)?0:1);

		}

}