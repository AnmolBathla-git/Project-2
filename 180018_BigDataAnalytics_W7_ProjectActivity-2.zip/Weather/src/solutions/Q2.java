package solutions;
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Q2 {
	
	//Mapper Class
	public static class MapForHotOrColdDay extends Mapper<LongWritable, Text, Text, FloatWritable>{
		
		public void map(LongWritable name, Text text, Context context) throws IOException, InterruptedException{
			
				String word = text.toString();
				String t_day = word.substring(6, 14).replaceAll(" ", "");
				String max = word.substring(38, 45).replaceAll(" ", "");
				String min = word.substring(46, 53).replaceAll(" ", "");
				Float max_Double = Float.parseFloat(max);
				Float min_Double = Float.parseFloat(min);
				FloatWritable min_Value = new FloatWritable(min_Double);
				FloatWritable max_Value = new FloatWritable(max_Double);
				
				if(min_Double < 10){
					context.write(new Text("Cold Day " + t_day), min_Value);
				}
				if(max_Double > 35){
					context.write(new Text("Hot Day " + t_day), max_Value);
				}
				
		}
	}
	
	//Reducer Class
	public static class ReduceForHotOrColdDay extends Reducer<Text, FloatWritable, Text, FloatWritable>{
				
		public void reduce(Text t_word, Iterable<FloatWritable> t_value, Context t_context) throws IOException, InterruptedException{
			
			float t = 0;
			for (FloatWritable value: t_value){
					t = value.get();
				
			}
			t_context.write(new Text(t_word), new FloatWritable(t));
		}
		
	}
	
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException{
		
		Configuration c= new Configuration();
		Job job = Job.getInstance(c, "hotorcoldDay:");
		job.setJarByClass(Q2.class);
		job.setMapperClass(MapForHotOrColdDay.class);
		job.setReducerClass(ReduceForHotOrColdDay.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(FloatWritable.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true)?0:1);
	}

}
