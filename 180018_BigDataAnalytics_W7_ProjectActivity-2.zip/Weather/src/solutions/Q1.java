package solutions;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class Q1 {

	//Mapper Class
	public static class MapForHighestTemperatureForEachyear extends Mapper<LongWritable, Text, Text, FloatWritable>{
		
		public void map(LongWritable name, Text text, Context context) throws IOException, InterruptedException{
			
				String word = text.toString();	
				String year = word.substring(6, 10).replaceAll(" ", "");
				Text output = new Text(year);
				
				String max = word.substring(38, 45).replaceAll(" ", "");
				Float max_Double = Float.parseFloat(max);
				FloatWritable outputvalue = new FloatWritable(max_Double);
				context.write(output, outputvalue);
		}
	}
	
	//Reducer Class
	public static class ReduceForHighestTemperatureForEachyear extends Reducer<Text, FloatWritable, Text, FloatWritable>{
				
		public void reduce(Text t_word, Iterable<FloatWritable> t_value, Context t_context) throws IOException, InterruptedException{
			
			float t_max = 0;
			for (FloatWritable value: t_value){
				if(value.get() > t_max){
					t_max = value.get();
				}
			}
			
			t_context.write(new Text("Highest Temperature for the Year " + t_word + " is "), new FloatWritable(t_max));
		}
		
	}
	
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException{
		
		Configuration c= new Configuration();
		Job job = Job.getInstance(c, "highestTemperature:");
		job.setJarByClass(Q1.class);
		job.setMapperClass(MapForHighestTemperatureForEachyear.class);
		job.setReducerClass(ReduceForHighestTemperatureForEachyear.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(FloatWritable.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true)?0:1);
	}
	
}
