package solutions;


import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Q3 {
	
	//Mapper Class
	public static class MapForTopTenColdestAndHottestDay extends Mapper<LongWritable, Text, DoubleWritable, Text>{
				
		public void map(LongWritable name, Text text, Context context) throws IOException, InterruptedException{
			
			String word = text.toString();
			String date = word.substring(6, 14).replaceAll(" ", "");
			String high = word.substring(38, 45).replaceAll(" ", "");
			String low = word.substring(46, 53).replaceAll(" ", "");

			double t_high = Double.parseDouble(high);
			double t_low = Double.parseDouble(low);

			context.write(new DoubleWritable(t_low), new Text(date));
			context.write(new DoubleWritable(t_high), new Text(date));

		}
			
	}
	
	//Reducer Class
	public static class ReduceForTopTenColdestAndHottestDay extends Reducer<DoubleWritable, Text, DoubleWritable, Text>{
		
		 TreeMap<DoubleWritable, Text> t_cold = new TreeMap<DoubleWritable, Text>();
		 TreeMap<DoubleWritable, Text> t_high = new TreeMap<DoubleWritable, Text>();
		 int i = 0;
		
		public void reduce(DoubleWritable t_word, Iterable<Text> t_value, Context t_context) throws IOException, InterruptedException{
			
			double t = t_word.get();
			String date = t_value.iterator().next().toString();

			// Input for Reduce comes sorted by default, so temperatures are
			// going to be in ascending order

			// For Top 10 Coldest Days, we need the first 10 key/value pairs
			// from the reduce input
			if (i < 10) {
				t_cold.put(new DoubleWritable(t), new Text(date));
				++i;
			}

			// For Top 10 Hottest Days, we need the last 10 key/value pairs from
			// the reduce input
			t_high.put(new DoubleWritable(t), new Text(date));
			if (t_high.size() > 10) {
				// Delete the first K/V
				t_high.remove(t_high.keySet().iterator().next());
			}
		}
		

		public void cleanup(Context con) throws IOException,
				InterruptedException {

			con.write(null, new Text("Top 10 Coldest Days: "));
			for (Map.Entry<DoubleWritable, Text> m : t_cold.entrySet()) {
				con.write(m.getKey(), m.getValue());
			}

			con.write(null, new Text("Top 10 Hottest Days: "));
			List<DoubleWritable> highTempKeys = new ArrayList<DoubleWritable>(
					t_cold.keySet());
			Collections.reverse(highTempKeys);

			for (int i = 0; i < highTempKeys.size(); i++) {
				con.write(highTempKeys.get(i), t_cold.get(highTempKeys.get(i)));
			}
		}

	}
	
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException{
		
		Configuration c= new Configuration();
		Job job = Job.getInstance(c, "Ten Hottest and Coldest Day:");
		job.setJarByClass(Q3.class);
		job.setMapperClass(MapForTopTenColdestAndHottestDay.class);
		job.setReducerClass(ReduceForTopTenColdestAndHottestDay.class);
		job.setOutputKeyClass(DoubleWritable.class);
		job.setOutputValueClass(Text.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true)?0:1);
	}

}